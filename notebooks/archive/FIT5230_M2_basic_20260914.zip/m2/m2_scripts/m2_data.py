"""
FIT5230 · Dark.ModelBreakers · Milestone 2 — data preparation.

Run from inside the official StealthDiffusion checkout with its Python 3.10 environment.

  python m2_data.py real     --out data --n_dev 10 --n_test 100
      Downloads Imagenette (a public 10-class subset of ImageNet, real photographs),
      takes validation images round-robin over the 10 classes, centre-crops and resizes
      them to 224x224 PNG:  data/real/dev/*.png  and  data/real/test/*.png

  python m2_data.py generate --out data --n_dev 10 --n_test 100 --model stable-diffusion-v1-5/stable-diffusion-v1-5
      Generates AI images with Stable Diffusion for the same 10 classes
      ("a photo of a <class>"), 512x512, then saves 224x224 PNG copies:
      data/gen/dev/*.png, data/gen/test/*.png  (512px originals in data/gen512/)

  python m2_data.py check    --out data
      Runs the four official detectors (E,R,D,S) on the dev sets and prints the clean
      accuracy and the label polarity (official convention: class 0 = AI, class 1 = real).

Every image is listed in a manifest CSV with its origin (file path or prompt+seed+model).
"""
import argparse
import csv
import os
import sys
import tarfile
import urllib.request

import numpy as np
from PIL import Image
from natsort import natsorted, ns

IMAGENETTE_URL = "https://s3.amazonaws.com/fast-ai-imagenette/imagenette2-320.tgz"
IMAGENETTE_CLASSES = [
    ("n01440764", "tench"), ("n02102040", "English springer spaniel"), ("n02979186", "cassette player"),
    ("n03000684", "chain saw"), ("n03028079", "church"), ("n03394916", "French horn"),
    ("n03417042", "garbage truck"), ("n03425413", "gas pump"), ("n03445777", "golf ball"),
    ("n03888605", "parachute"),
]
RES = 224


def center_square_resize(pil, res=RES):
    pil = pil.convert("RGB")
    w, h = pil.size
    s = min(w, h)
    left, top = (w - s) // 2, (h - s) // 2
    return pil.crop((left, top, left + s, top + s)).resize((res, res), resample=Image.LANCZOS)


def write_manifest(path, rows, fields):
    with open(path, "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        w.writerows(rows)


def cmd_real(args):
    root = os.path.join(args.out, "imagenette2-320")
    if not os.path.isdir(root):
        tgz = os.path.join(args.out, "imagenette2-320.tgz")
        os.makedirs(args.out, exist_ok=True)
        if not os.path.exists(tgz):
            print(f"[data] downloading {IMAGENETTE_URL} (~340 MB)", flush=True)
            urllib.request.urlretrieve(IMAGENETTE_URL, tgz)
        print("[data] extracting", flush=True)
        with tarfile.open(tgz) as tf:
            tf.extractall(args.out)
    val_root = os.path.join(root, "val")
    per_class = {}
    for wnid, name in IMAGENETTE_CLASSES:
        files = natsorted([f for f in os.listdir(os.path.join(val_root, wnid)) if f.lower().endswith((".jpeg", ".jpg", ".png"))], alg=ns.PATH)
        rng = np.random.default_rng(args.seed + len(per_class))
        rng.shuffle(files)
        per_class[wnid] = [os.path.join(val_root, wnid, f) for f in files]
    # round-robin over classes so every split is class balanced
    order = []
    i = 0
    while len(order) < args.n_dev + args.n_test:
        for wnid, _ in IMAGENETTE_CLASSES:
            if i < len(per_class[wnid]):
                order.append((wnid, per_class[wnid][i]))
        i += 1
    order = order[: args.n_dev + args.n_test]
    splits = {"dev": order[: args.n_dev], "test": order[args.n_dev:]}
    names = dict(IMAGENETTE_CLASSES)
    for split, items in splits.items():
        out_dir = os.path.join(args.out, "real", split)
        os.makedirs(out_dir, exist_ok=True)
        rows = []
        for k, (wnid, path) in enumerate(items):
            image_id = str(k).rjust(4, "0")
            center_square_resize(Image.open(path)).save(os.path.join(out_dir, image_id + ".png"))
            rows.append({"image_id": image_id, "class": names[wnid], "wnid": wnid, "source": os.path.relpath(path, args.out)})
        write_manifest(os.path.join(out_dir, "manifest.csv"), rows, ["image_id", "class", "wnid", "source"])
        print(f"[data] real/{split}: {len(rows)} images -> {out_dir}", flush=True)


def cmd_generate(args):
    import torch
    from diffusers import StableDiffusionPipeline

    kwargs = {"torch_dtype": torch.float16, "safety_checker": None}
    try:
        pipe = StableDiffusionPipeline.from_pretrained(args.model, requires_safety_checker=False, **kwargs)
    except TypeError:
        pipe = StableDiffusionPipeline.from_pretrained(args.model, **kwargs)
    pipe = pipe.to("cuda")
    pipe.set_progress_bar_config(disable=True)
    total = args.n_dev + args.n_test
    names = [n for _, n in IMAGENETTE_CLASSES]
    prompts = [f"a photo of a {names[k % len(names)]}" for k in range(total)]
    seeds = [args.seed * 1000 + k for k in range(total)]
    out512 = os.path.join(args.out, "gen512")
    os.makedirs(out512, exist_ok=True)
    rows = []
    for start in range(0, total, args.batch_size):
        idx = list(range(start, min(start + args.batch_size, total)))
        gens = [torch.Generator(device="cuda").manual_seed(seeds[k]) for k in idx]
        with torch.no_grad():
            images = pipe([prompts[k] for k in idx], num_inference_steps=args.steps, guidance_scale=args.guidance,
                          height=512, width=512, generator=gens).images
        for k, im in zip(idx, images):
            image_id = str(k).rjust(4, "0")
            im.save(os.path.join(out512, image_id + ".png"))
            rows.append({"image_id": image_id, "prompt": prompts[k], "seed": seeds[k], "model": args.model,
                         "steps": args.steps, "guidance": args.guidance})
        print(f"[data] generated {min(start + args.batch_size, total)}/{total}", flush=True)
    for split, lo, hi in [("dev", 0, args.n_dev), ("test", args.n_dev, total)]:
        out_dir = os.path.join(args.out, "gen", split)
        os.makedirs(out_dir, exist_ok=True)
        split_rows = []
        for k in range(lo, hi):
            src = str(k).rjust(4, "0")
            image_id = str(k - lo).rjust(4, "0")
            Image.open(os.path.join(out512, src + ".png")).resize((RES, RES), resample=Image.LANCZOS).save(
                os.path.join(out_dir, image_id + ".png"))
            r = dict(rows[k]); r["image_id"] = image_id; r["source512"] = f"gen512/{src}.png"
            split_rows.append(r)
        write_manifest(os.path.join(out_dir, "manifest.csv"), split_rows,
                       ["image_id", "prompt", "seed", "model", "steps", "guidance", "source512"])
        print(f"[data] gen/{split}: {len(split_rows)} images -> {out_dir}", flush=True)


def cmd_check(args):
    import torch
    from torchvision import transforms
    import other_attacks
    os.environ["CUDA_VISIBLE_DEVICES"] = "0"
    normalize = transforms.Normalize([0.485, 0.456, 0.406], [0.229, 0.224, 0.225])

    def load_dir(d):
        files = natsorted([f for f in os.listdir(d) if f.endswith(".png")], alg=ns.PATH)
        x = np.stack([np.float32(Image.open(os.path.join(d, f)).convert("RGB")) / 255.0 for f in files])
        return torch.from_numpy(x).permute(0, 3, 1, 2)

    real = load_dir(os.path.join(args.out, "real", "dev"))
    gen = load_dir(os.path.join(args.out, "gen", "dev"))
    print(f"[check] dev real {tuple(real.shape)} | dev generated {tuple(gen.shape)}")
    print(f"{'detector':<10}{'acc(real->1)':>14}{'acc(gen->0)':>13}{'margin real':>13}{'margin gen':>12}")
    rows = []
    for name in args.detectors.split(","):
        det = other_attacks.model_selection(name).eval()
        det.requires_grad_(False)
        out = {}
        for tag, x in [("real", real), ("gen", gen)]:
            preds, margins = [], []
            with torch.no_grad():
                for i in range(0, len(x), 16):
                    logits = det(normalize(x[i:i + 16].cuda()))
                    preds += torch.argmax(logits, 1).tolist()
                    margins += (logits[:, 1] - logits[:, 0]).tolist()
            out[tag] = (np.array(preds), np.array(margins))
        acc_real = float((out["real"][0] == 1).mean())
        acc_gen = float((out["gen"][0] == 0).mean())
        print(f"{name:<10}{acc_real:>14.2f}{acc_gen:>13.2f}{out['real'][1].mean():>13.2f}{out['gen'][1].mean():>12.2f}")
        if acc_real < 0.5 and acc_gen < 0.5:
            print(f"   WARNING: {name} looks label-inverted on this data; check the checkpoint/polarity")
        rows.append({"detector": name, "acc_real": acc_real, "acc_gen": acc_gen,
                     "margin_real": float(out["real"][1].mean()), "margin_gen": float(out["gen"][1].mean())})
        del det
        torch.cuda.empty_cache()
    write_manifest(os.path.join(args.out, "dev_check.csv"), rows,
                   ["detector", "acc_real", "acc_gen", "margin_real", "margin_gen"])


def main(argv=None):
    p = argparse.ArgumentParser(description=__doc__, formatter_class=argparse.RawDescriptionHelpFormatter)
    p.add_argument("mode", choices=["real", "generate", "check"])
    p.add_argument("--out", default="data")
    p.add_argument("--n_dev", type=int, default=10)
    p.add_argument("--n_test", type=int, default=100)
    p.add_argument("--seed", type=int, default=5230)
    p.add_argument("--model", default="stable-diffusion-v1-5/stable-diffusion-v1-5",
                   help="Hugging Face id of the generator (alternative: Manojb/stable-diffusion-2-1-base)")
    p.add_argument("--steps", type=int, default=30)
    p.add_argument("--guidance", type=float, default=7.5)
    p.add_argument("--batch_size", type=int, default=4)
    p.add_argument("--detectors", default="E,R,D,S")
    args = p.parse_args(argv)
    {"real": cmd_real, "generate": cmd_generate, "check": cmd_check}[args.mode](args)


if __name__ == "__main__":
    main()
