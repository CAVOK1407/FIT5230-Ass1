"""CPU smoke test for the M2 scripts using stub (random) models.

It exercises the real control flow of m2_stealth.py / m2_evaluate.py / m2_challenge.py
inside the pinned upstream checkout, with:
  * a tiny random UNet, the real AutoencoderKL architecture (random weights),
  * a stub tokenizer / text encoder,
  * tiny CNN detectors wrapped exactly like the official OURS wrapper,
  * a stub LPIPS,
  * .cuda() patched to a no-op.
It checks that every variant runs end to end, writes the expected files, and that the
latent actually receives gradient (the objective changes across iterations).
"""
import json
import os
import shutil
import sys
import types

import numpy as np
import torch
import torch.nn as nn
from PIL import Image

UPSTREAM = sys.argv[1] if len(sys.argv) > 1 else os.path.abspath("upstream")
SCRIPTS = sys.argv[2] if len(sys.argv) > 2 else os.path.abspath("m2build/scripts")
WORK = os.path.abspath("m2build/tests/work")
RES = 64

os.chdir(UPSTREAM)
sys.path.insert(0, UPSTREAM)
sys.path.insert(0, SCRIPTS)

# ---- make the CUDA-only upstream code run on CPU ----
torch.Tensor.cuda = lambda self, *a, **k: self  # type: ignore
nn.Module.cuda = lambda self, *a, **k: self  # type: ignore

import other_attacks  # noqa: E402
from ControlVAE import NewEncoder  # noqa: E402
from diffusers import AutoencoderKL, UNet2DConditionModel, DDIMScheduler  # noqa: E402

import m2_stealth  # noqa: E402
import m2_evaluate  # noqa: E402
import m2_challenge  # noqa: E402

torch.manual_seed(0)


class TinyDetector(nn.Module):
    def __init__(self, seed):
        super().__init__()
        torch.manual_seed(seed)
        self.net = nn.Sequential(nn.Conv2d(3, 8, 3, 2, 1), nn.ReLU(), nn.Conv2d(8, 8, 3, 2, 1), nn.ReLU(),
                                 nn.AdaptiveAvgPool2d(1), nn.Flatten(), nn.Linear(8, 1))

    def forward(self, x):
        return self.net(x)


def stub_model_selection(name):
    return other_attacks.OURS(TinyDetector({"E": 1, "R": 2, "D": 3, "S": 4}[name]))


other_attacks.model_selection = stub_model_selection
m2_evaluate.other_attacks.model_selection = stub_model_selection


class StubTokenizer:
    model_max_length = 77

    def __call__(self, texts, **kw):
        if isinstance(texts, str):
            texts = [texts]
        return types.SimpleNamespace(input_ids=torch.zeros(len(texts), 77, dtype=torch.long))

    def encode(self, text):
        return [0, 1]


class StubTextEncoder(nn.Module):
    def __init__(self):
        super().__init__()
        self.emb = nn.Parameter(torch.randn(77, 32) * 0.1)

    def forward(self, input_ids):
        return [self.emb[None].expand(input_ids.shape[0], -1, -1)]


class StubPipeline:
    def __init__(self):
        self.vae = AutoencoderKL(**{k: v for k, v in m2_stealth.CVAE_PARAMS.items()})
        self.unet = UNet2DConditionModel(sample_size=RES // 8, in_channels=4, out_channels=4,
                                         block_out_channels=(32, 64), layers_per_block=1,
                                         down_block_types=("CrossAttnDownBlock2D", "DownBlock2D"),
                                         up_block_types=("UpBlock2D", "CrossAttnUpBlock2D"),
                                         cross_attention_dim=32, attention_head_dim=8)
        self.scheduler = DDIMScheduler(beta_start=0.00085, beta_end=0.012, beta_schedule="scaled_linear",
                                       num_train_timesteps=1000, clip_sample=False, set_alpha_to_one=False,
                                       steps_offset=1)
        self.tokenizer = StubTokenizer()
        self.text_encoder = StubTextEncoder()
        self.device = torch.device("cpu")

    @classmethod
    def from_pretrained(cls, path, **kw):
        return cls()

    def to(self, device):
        return self


class StubLPIPS(nn.Module):
    def forward(self, a, b):
        return (a - b).abs().mean(dim=(1, 2, 3))


m2_stealth.StableDiffusionPipeline = StubPipeline
m2_stealth.build_lpips = lambda: StubLPIPS()

# ---- fixtures ----
shutil.rmtree(WORK, ignore_errors=True)
os.makedirs(os.path.join(WORK, "inputs"))
os.makedirs(os.path.join(WORK, "real"))
os.makedirs(os.path.join(WORK, "checkpoints"))
rng = np.random.default_rng(0)
for i in range(3):
    Image.fromarray(rng.integers(0, 255, (RES, RES, 3), dtype=np.uint8)).save(os.path.join(WORK, "inputs", f"gen_{i}.png"))
for i in range(4):
    Image.fromarray(rng.integers(0, 255, (RES, RES, 3), dtype=np.uint8)).save(os.path.join(WORK, "real", f"{i:04d}.png"))
torch.save({"encoder": NewEncoder(**m2_stealth.CVAE_ENCODER_PARAMS).state_dict()}, os.path.join(WORK, "checkpoints", "Controlvae.pt"))

common = ["--images_root", os.path.join(WORK, "inputs"), "--encoder_weights", os.path.join(WORK, "checkpoints", "Controlvae.pt"),
          "--res", str(RES), "--iterations", "3", "--max_images", "2"]
variants = {
    "B00": [],
    "B10": ["--decode_path", "final"],
    "ENS": ["--surrogates", "E,R,D"],
    "FULL": ["--surrogates", "E,R,D", "--decode_path", "final", "--loss", "margin", "--lpips_weight", "1.0", "--di_prob", "0.5"],
}
for name, extra in variants.items():
    save_dir = os.path.join(WORK, "runs", name)
    m2_stealth.main(common + ["--save_dir", save_dir] + extra)
    for i in range(2):
        for suffix in ("_originImage.png", "_plain_vae.png", "_adv_image.png"):
            path = os.path.join(save_dir, f"{i:04d}{suffix}")
            assert os.path.exists(path), path
            assert Image.open(path).size == (RES, RES)
    with open(os.path.join(save_dir, "records.jsonl")) as f:
        records = [json.loads(l) for l in f if l.strip()]
    assert len(records) == 2, records
    hist = records[0]["history"]
    assert len(hist) == 3
    losses = [h["loss"] for h in hist]
    assert len(set(round(v, 6) for v in losses)) > 1, f"{name}: objective did not change -> no gradient to latent? {losses}"
    n_sur = len(hist[0]["margins"])
    assert n_sur == (3 if "E,R,D" in " ".join(extra) else 1)
    assert set(records[0]["final"]) == {"E", "R", "D", "S"}
    print(f"[test] variant {name}: ok, losses={['%.3f' % v for v in losses]}, psnr={records[0]['psnr']:.2f}")

# resume must skip completed images
m2_stealth.main(common + ["--save_dir", os.path.join(WORK, "runs", "B00"), "--resume"])
with open(os.path.join(WORK, "runs", "B00", "records.jsonl")) as f:
    assert len([l for l in f if l.strip()]) == 2, "resume re-ran finished images"

# ---- evaluation on the saved PNGs ----
m2_evaluate.RES = RES
m2_evaluate.main(["--runs", *[f"{n}={os.path.join(WORK, 'runs', n)}" for n in variants],
                  "--real_dir", os.path.join(WORK, "real"), "--out", os.path.join(WORK, "eval"),
                  "--detectors", "E,R,D,S", "--conditions", "none,jpeg75,resize05", "--no_lpips"])
with open(os.path.join(WORK, "eval", "summary.json")) as f:
    summary = json.load(f)["summary"]
assert len(summary) == 4 * 4 * 3, len(summary)
assert all("cond_asr" in r and "auc_real_vs_adv" in r for r in summary)
print("[test] evaluation ok:", summary[0])

# ---- challenge package ----
m2_challenge.main(["build", "--real_dir", os.path.join(WORK, "real"), "--gen_dir", os.path.join(WORK, "inputs"),
                   "--attack_dir", os.path.join(WORK, "runs", "FULL"), "--n_per_group", "2", "--out", os.path.join(WORK, "challenge")])
assert os.path.exists(os.path.join(WORK, "challenge", "challenge_public.zip"))
import csv  # noqa: E402
key_path = os.path.join(WORK, "challenge", "private", "challenge_key.csv")
with open(key_path) as f:
    rows = list(csv.DictReader(f))
sub_path = os.path.join(WORK, "challenge", "sub.csv")
with open(sub_path, "w", newline="") as f:
    w = csv.writer(f)
    w.writerow(["image_id", "pred_label"])
    for r in rows:
        w.writerow([r["image_id"], 1])  # everything "generated"
m2_challenge.main(["score", "--key", key_path, "--submission", sub_path, "--team", "test", "--save", os.path.join(WORK, "challenge", "score.json")])
with open(os.path.join(WORK, "challenge", "score.json")) as f:
    score = json.load(f)
assert score["detection_rate_attacked"] == 1.0 and score["false_positive_rate_real"] == 1.0, score
print("[test] challenge ok")
print("ALL CPU STUB TESTS PASSED")
