"""Execute the analysis cells of the generated notebook against the stub-test outputs."""
import json, os, sys
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from pathlib import Path
import pandas as pd

NB = sys.argv[1]
WORK = Path(sys.argv[2])
nb = json.load(open(NB))
cells = ["".join(c["source"]) for c in nb["cells"] if c["cell_type"] == "code"]
def find(title):
    for c in cells:
        if c.splitlines()[0].startswith("#@title " + title):
            return c
    raise KeyError(title)

env = {
    "display": lambda x: print(x.to_string() if hasattr(x, "to_string") else x),
    "pd": pd, "plt": plt, "json": json, "Path": Path,
    "VARIANTS": {"B00": [], "B10": [], "ENS": [], "FULL": []},
    "RUNS": WORK / "runs", "EVAL": WORK / "eval", "DATA": WORK, "DRIVE_ROOT": str(WORK),
    "N_ATTACK": 2,
}
env["summary"] = pd.read_csv(env["EVAL"] / "summary.csv")
env["per_image"] = pd.read_csv(env["EVAL"] / "per_image.csv")
plt.show = lambda: None
for title in ["5.2", "6.2", "6.3", "6.4", "6.5", "6.6", "6.7"]:
    src = find(title)
    print(f"\n===== cell {title} =====")
    exec(compile(src, f"cell_{title}", "exec"), env)
print("\nNOTEBOOK ANALYSIS CELLS OK")
